'use strict';

var jsonlint = require("jsonlint");
var crypto = require('crypto');
var fs = require('node-fs');
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var url = 'mongodb://localhost:27017/testDB';
var findUserName = '';


var f_app_config = 'node-server.json';
var app_config = {};
if (fs.existsSync(f_app_config)) {
    var configBody = fs.readFileSync(f_app_config, 'utf8');
    try {
        jsonlint.parse(configBody);
    } catch (err) {
        console.log("JSON syntax err in file ", f_app_config);
        console.log(err.message);
        process.exit(1);
    }
    app_config = JSON.parse(fs.readFileSync(f_app_config, 'utf8'));
} else {
    console.log("Can't find config file " + f_app_config);
    process.exit(1);
}

var f_help_url_config = app_config['help_url'];

if(f_help_url_config == null) {
    console.log("Can't find help_url parameter");
    process.exit(1);
}

if (fs.existsSync(f_help_url_config)) {
    var helpConfigBody = fs.readFileSync(f_help_url_config, 'utf8');
    try {
        jsonlint.parse(helpConfigBody);
    } catch (err) {
        console.log("JSON syntax err in file ", f_help_url_config);
        console.log(err.message);
        process.exit(1);
    }
    app_config['help_url'] = JSON.parse(fs.readFileSync(f_help_url_config, 'utf8'));
} else {
    console.log("Can't find help config file " + f_help_url_config);
    process.exit(1);
}


var id_service = app_config['id_service'];
var sitepath = app_config['sitepath'];
var port = app_config['port'];
var api_host = app_config['api_host'];
var check_activity = app_config['check_activity'];
var http_request_timeout_ms = parseInt(app_config['http_request_timeout_ms']);
var web_session_timeout_min = parseInt(app_config['web_session_timeout_min']);
var uploads_path = app_config['uploads_path'];

console.log("api_host['auth'] = " + api_host['auth']);
console.log("api_host['contract'] = " + api_host['contract']);
console.log("web_session_timeout_min = " + web_session_timeout_min);

var express = require('express');
var http = require('http');
var path = require('path');
var request = require('request');
var favicon = require('serve-favicon');
var morgan = require('morgan'); // formerly express.logger
var errorhandler = require('errorhandler');
var cookieParser = require('cookie-parser');
var session = require('express-session');
//var mongoose = require('mongoose');

http.globalAgent.maxSockets = 1000000;
var separateReqPool = {maxSockets: 100};
var app = express();

app.all('/*', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With, Origin");
    res.header("Access-Control-Allow-Methods", "POST, GET, PUT, DELETE, OPTIONS");
    res.header("Access-Control-Allow-Credentials", true);
    next();
});

var bodyParser = require('body-parser');
app.use(bodyParser.json());       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({   // to support URL-encoded bodies
    extended: true
}));

//var MongoStore = require('connect-mongo')(session);
//var MongoStore = require('connect-mongostore')(session);

app.use(cookieParser());
app.use(session({
    secret: 'NFIueiur#348yfwb9nm0ufbw;j=ughfd',
    key: 'sessid',
    cookie: {
        path: '/',
        httpOnly: true,
        maxAge: 1000 * 60 * web_session_timeout_min 
    },
    rolling: true, 
    resave: true,
    saveUninitialized: false,
    //store: new MongoStore({'db': 'sessions'})
}));

var multer = require('multer');

var storage = multer.diskStorage({ //multers disk storage settings
    destination: function (req, file, cb) {
        cb(null, uploads_path);
    },
    filename: function (req, file, cb) {
        cb(null, file.originalname);
    }
});

var upload = multer({ //multer settings
    storage: storage
}).single('file');

// all environments
app.set('port', process.env.PORT || port);
app.set('views', path.join(__dirname, 'views'));
app.engine('html', require('ejs').renderFile);
app.engine('.html', require('ejs').__express);

// express/connect middleware
app.use(favicon(__dirname + '/app/favicon.ico'));
app.use(morgan('dev'));

// serve up static assets
app.use(express.static(path.join(__dirname, 'app')));

// development only
if ('development' === app.get('env')) {
    app.use(errorhandler());
}

http.createServer(app).listen(app.get('port'), function () {
    console.log(id_service + ' listening on port ' + app.get('port'));
});

function trace(obj) {
    console.log(JSON.stringify(obj, null, 2))
}

var requestCount = 0;

//----------------------------------
// --------------------------------- AUTH {
//----------------------------------

app.post(sitepath + '/api/auth/checkLogin', function (req, res) {

    var _requestCount = ++requestCount;

    var resp_json = {};

    if (req.session && req.session.token) {
        
        
        //-----------------------------------------------------------
        //for Heatmap
        findUserName = req.session.login;
        //console.log(findUserName);
        //------------------------------------------------------------
        
        
        var req_json = {
            uri: api_host['auth'] + "/api/tokenauth/authenticate",
            method: "POST",
            timeout: http_request_timeout_ms,
            pool: separateReqPool,
            json: true,
            headers: {
                "content-type": "application/json"
            },
            body: {
                token: req.session.token
            }
        };

        console.log('Request #' + _requestCount, api_host['auth'] + "/api/tokenauth/authenticate");
        trace(req_json.body);

        request(req_json, function (err, response, json) {
            if (err) {
                req.session.destroy();
                console.log('Bad response #' + _requestCount, api_host['auth'] + "/api/tokenauth/authenticate", 'error', err);
                res.status(500);
                res.send({alerts: [{type: 'danger', msg: '500 Internal Server Error'}]});
                res.end();
            } else {
                console.log('Response #' + _requestCount, api_host['auth'] + "/api/tokenauth/authenticate", 'statusCode', response.statusCode);
                if (response.statusCode == 200) {
                    resp_json = {
                        login: req.session.login,
                        initPage: app_config['init_page']
                    };
                }
                res.status(response.statusCode);
                res.send(resp_json);
                res.end();
            }
        });
    } else {
        res.status(401);
        res.send({alerts: [{type: 'danger', msg: '401 Unauthorized'}]});
        res.end();
    }
});

app.post(sitepath + '/api/auth/login', function (req, res) {

    var _requestCount = ++requestCount;

    var resp_json = {};

    var req_json = {
        uri: api_host['auth'] + "/api/tokenauth/authorize",
        method: "POST",
        timeout: http_request_timeout_ms,
        pool: separateReqPool,
        json: true,
        headers: {
            "content-type": "application/json"
        },
        body: {
            user: req.body.login,
            hashedPass: crypto.createHash('md5').update(req.body.password).digest("hex"),
            lang: req.body.lang
        }
    };

    console.log('Request #' + _requestCount, api_host['auth'] + "/api/tokenauth/authorize");
    trace(req_json.body);

    request(req_json, function (err, response, json) {
        if (err) {
            req.session.destroy();
            console.log('Bad response #' + _requestCount, api_host['auth'] + "/api/tokenauth/authorize", 'error', err);
            res.status(500);
            res.send({alerts: [{type: 'danger', msg: '500 Internal Server Error'}]});
            res.end();
        } else {
            console.log('Response #' + _requestCount, api_host['auth'] + "/api/tokenauth/authorize", 'statusCode', response.statusCode);
            trace(json);
            resp_json = json;

            if (response.statusCode == 200) {
                req.session.token = resp_json.token;
                req.session.login = req.body.login;

                resp_json = {
                    login: req.session.login,
                    token: req.session.token,
                    initPage: app_config['init_page']
                };
            }
            res.status(response.statusCode);
            res.send(resp_json);
            res.end();
        }
    });
});

app.post(sitepath + '/api/auth/roles', function (req, res) {
    api_request(req, res, api_host['auth'] + "/api/tokenauth/getRoles");
});

app.post(sitepath + '/api/auth/logout', function (req, res) {

    var _requestCount = ++requestCount;

    if (req.session == null || req.session.token == null) {
        res.status(401);
        res.send({alerts: [{type: 'danger', msg: '401 Unauthorized'}]});
        return;
    }

    var resp_json = {};

    var req_json = {
        uri: api_host['auth'] + "/api/tokenauth/deAuthorize",
        method: "POST",
        timeout: http_request_timeout_ms,
        pool: separateReqPool,
        json: true,
        headers: {
            "content-type": "application/json"
        },
        body: req.body
    };
    req_json.body['token'] = req.session.token; 

    console.log('Request #' + _requestCount, api_host['auth'] + "/api/tokenauth/deAuthorize");
    trace(req_json.body);

    request(req_json, function (err, response, json) {
        if (err) {
            req.session.destroy();
            console.log('Bad response #' + _requestCount, api_host['auth'] + "/api/tokenauth/deAuthorize", 'error', err);
            res.status(500);
            res.send({alerts: [{type: 'danger', msg: '500 Internal Server Error'}]});
            res.end();
        } else {
            console.log('Response #' + _requestCount, api_host['auth'] + "/api/tokenauth/deAuthorize", 'statusCode', response.statusCode);
            trace(json);
            resp_json = json;
            if (response.statusCode == 200) {
                req.session.destroy();
            }
            res.status(response.statusCode);
            res.send(resp_json);
            res.end();
        }
    });
});

//----------------------------------
// --------------------------------- } AUTH
//----------------------------------

// proxy request to desired API
function api_request(req, res, api_url) {

    var _requestCount = ++requestCount;

    if (req.session == null || req.session.token == null) {
        res.status(401);
        res.send({alerts: [{type: 'danger', msg: '401 Unauthorized'}]});
        res.end();
        return;
    }

    var req_json = {
        uri: api_url, method: "POST", timeout: http_request_timeout_ms, pool: separateReqPool, json: true,
        headers: {
            "content-type": "application/json"
        },
        body: req.body
    };
    req_json.body['token'] = req.session.token; 

    console.log('Request #' + _requestCount, api_url);
    trace(req.body);

    request(req_json, function (err, response, json) {
        if (err) {
            console.log('Bad response #' + _requestCount, api_url, 'error', err);
            res.status(500);
            res.send({alerts: [{type: 'danger', msg: '500 Internal Server Error'}]});
            res.end();
        } else {
            console.log('Response #' + _requestCount, api_url, 'statusCode', response.statusCode);
            trace(json);
            if (response.statusCode == 401) { 
                req.session.destroy();
            }
            res.status(response.statusCode);
            res.send(json);
            res.end();
        }
    });
}

// MAIN route preback
app.post(sitepath + '/api/preback', function (req, res) {
    var isError = false;
    var errorText = "";

    if(req.body["apiName"] == null) {
        isError = true;
        errorText = "Can't find parameter apiName";
    }
    if(req.body["apiPath"] == null) {
        isError = true;
        errorText = "Can't find parameter apiPath";
    }
    if(api_host[req.body.apiName] == null) {
        isError = true;
        errorText = "Can't find API for apiName = " + req.body.apiName;
    }

    if(isError) {
        res.status(500);
        res.json({
            alerts: [
                {
                    type: 'danger',
                    msg: errorText,
                    errorCode: errorText
                }
            ]
        });
        return;
    }

    api_request(req, res, api_host[req.body.apiName] + req.body.apiPath);
});


//================================================================================
//======================= HEATMAP ================================================
//================================================================================


var body = {};
var pointArr = {};
var d = new Date();
//var month = d.getMonth()+1;
//var day = d.getDate() + "/" + month + "/" + d.getFullYear();


app.post(sitepath + '/api/heatmap/save', function (req, res) {
    body = req.body;
  //  console.log(body);
   // debugger;
    if(body == 0){
        console.log("Data is received");
    }if(findUserName == ''){
        console.log("Username is received");
    }
    else {

        pointArr = {
            'name': findUserName, 
            'date' : d,
            'pointsUse': body
        };
        MongoClient.connect(url, function (err, db) {
            db.createCollection('points_list');
            console.log("Connected correctly to server");
            var coll = db.collection('points_list');
            coll.insertMany([pointArr], function(err, result) {
                assert.equal(err, null);
                console.log(pointArr);
                console.log("Inserted documents into the document collection");
                db.close();
            });
        });
    }
    res.end('ok');
});

app.post(sitepath + '/api/heatmap/load', function (req, res) {
    body = req.body;
    var loadingPoints=[];
    res.setHeader('Content-Type', 'application/json');
    MongoClient.connect(url, function(err, db) {
        var coll = db.collection('points_list');
        coll.find({}).toArray(function(err, docs) {
            assert.equal(err, null);
            assert.equal(docs.length, docs.length);
            console.log("Found the following records");
            console.log(docs);
            for (var i = 0; i < docs.length; i++) {
                var d = Date.parse(docs[i].date);
                var f = Date.parse(body.fromD);
                var u = Date.parse(body.untilD) + 1000*60*60*6;

                if (body.nameP == 'all' && d >= f &&  d <= u) {
                    loadingPoints = loadingPoints.concat(docs[i].pointsUse);
                }
                if (body.nameP == findUserName && docs[i].name == findUserName && d >= f &&  d <= u) {
                    loadingPoints = loadingPoints.concat(docs[i].pointsUse);
                }
            }
            db.close();
            res.send(JSON.stringify(loadingPoints));
            res.end();
        });

    });
});
//================================================================================
//======================= END HEATMAP ============================================
//================================================================================


app.get(sitepath + '/api/help', function (req, res) {
    if (req.session == null || req.session.token == null) {
        res.writeHead(302, {
            'Location': app_config['error_401_url']
        });
        res.end();
        return;
    }

    try {
        console.log(JSON.stringify(req.query, null, 2));
        var lang = req.query.lang;
        var section = req.query.section;
        var page = req.query.page;
        var url = app_config['help_url'][section][page][lang];
        console.log('help url is', url);
        req.pipe(request(url)).pipe(res);
    } catch(e) {
        console.log(e);
        res.writeHead(302, {
            'Location': app_config['error_400_url']
        });
        res.end();
    }
});

// ---- checkActivity

var mapActivity = {};

app.post(sitepath + '/api/preback/updActivity', function (req, res) {
    if (req.session == null || req.session.token == null) {
        res.status(401);
        res.send({alerts: [{type: 'danger', msg: '401 Unauthorized'}]});
        res.end();
        return;
    }

    mapActivity[req.session.token] = {
        params: req.body,
        updTime: (new Date()).getTime()
    };

    res.json(mapActivity[req.session.token]);
    res.end();
});

app.post(sitepath + '/api/preback/killActivity', function (req, res) {
    if (req.session == null || req.session.token == null) {
        res.status(401);
        res.send({alerts: [{type: 'danger', msg: '401 Unauthorized'}]});
        res.end();
        return;
    }

    if(mapActivity[req.session.token]) {
        res.json(mapActivity[req.session.token]);
        delete mapActivity[req.session.token];
    }

    res.end();

});

app.post(sitepath + '/demo/killActivity', function (req, res) {
    res.json(req.body);
    res.end();
});

function checkActivity() {

    for (var token in mapActivity) {
        if (mapActivity.hasOwnProperty(token)) {
            if ((new Date()).getTime() - mapActivity[token].updTime > Number(check_activity['timeout_sec']) * 1000) {

                var _requestCount = ++requestCount;

                var api_url = check_activity['url'];

                var req_json = {
                    uri: api_url, method: "POST", timeout: http_request_timeout_ms, pool: separateReqPool, json: true,
                    headers: {
                        "content-type": "application/json"
                    },
                    body: mapActivity[token].params
                };

                req_json.body['token'] = token;

                console.log('Request #' + _requestCount, api_url);
                trace(req_json.body);

                request(req_json, function (err, response, json) {
                    if (err) {
                        console.log('Bad response #' + _requestCount, api_url, 'error', err);
                    } else {
                        console.log('Response #' + _requestCount, api_url, 'statusCode', response.statusCode);
                        trace(json);
                    }
                });

                delete mapActivity[token];
            }
        }
    }
}

function cron_checkActivity() {
    checkActivity();
}

if(check_activity && check_activity['url'] && check_activity['timeout_sec']) {
    console.log('Start check activity cron');
    setInterval(cron_checkActivity, 1000);
} else {
    console.log('Can`t start cron for activity check - `check_activity` in config is:\n', JSON.stringify(check_activity, null, 2))
}

