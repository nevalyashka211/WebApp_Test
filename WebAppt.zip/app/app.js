'use strict';

function steps() {
    return {
        templateUrl: function (elem, attr) {
            return 'components/contract/steps/' + attr.st + '.html';
        }
    }
}
angular.module('myApp', [
    'oi.select',
    'ngAnimate',
    'ngSanitize',
    'ui.bootstrap',
    'mgcrea.ngStrap',
    'agGrid',
    'ngRoute',
    'myApp.viewLogin',
    'myApp.viewInitPage',
    'myApp.viewNotAnyRoles',
    'myApp.viewNotValidRoles',
    'isteven-multi-select',
    'gettext',
    'ngMessages',
    'angularMoment',
    'ipCookie',
    'xtForm',
    'ngFileUpload',
    'cfp.hotkeys',
    'tmh.dynamicLocale'

])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.otherwise({redirectTo: '/viewLogin'});
    }])
    .config(function(tmhDynamicLocaleProvider) {
        tmhDynamicLocaleProvider.localeLocationPattern('https://cdnjs.cloudflare.com/ajax/libs/angular.js/1.4.4/i18n/angular-locale_{{locale}}.js');
    })
    .directive('steps', steps);

