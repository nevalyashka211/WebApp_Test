'use strict';

angular.module('myApp.viewNotAnyRoles', ['ngAnimate', 'ngRoute', 'ui.bootstrap'])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/viewNotAnyRoles', {
            templateUrl: 'viewNotAnyRoles/viewNotAnyRoles.html',
            //controller: 'ViewContractController'
        });
    }]);
