'use strict';

describe('pandaApp.viewNotAnyRoles module', function() {

  beforeEach(module('pandaApp.viewNotAnyRoles'));

  describe('viewLogin controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var viewNotAnyRolesCtrl = $controller('viewNotAnyRolesCtrl');
      expect(viewNotAnyRolesCtrl).toBeDefined();
    }));

  });
});