'use strict';

angular.module('myApp.viewNotValidRoles', ['ngAnimate', 'ngRoute', 'ui.bootstrap'])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/viewNotValidRoles', {
            templateUrl: 'viewNotValidRoles/viewNotValidRoles.html',
            //controller: 'ViewContractController'
        });
    }]);
