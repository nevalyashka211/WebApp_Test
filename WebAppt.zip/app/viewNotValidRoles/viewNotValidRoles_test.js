'use strict';

describe('pandaApp.viewNotValidRoles module', function() {

  beforeEach(module('pandaApp.viewNotValidRoles'));

  describe('viewNotValidRoles controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var viewNotValidRolesCtrl = $controller('viewNotValidRolesCtrl');
      expect(viewNotValidRolesCtrl).toBeDefined();
    }));

  });
});