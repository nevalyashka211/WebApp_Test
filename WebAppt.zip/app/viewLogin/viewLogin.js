'use strict';

// контроллер для таблицы
function ViewLoginController($scope, $location, $http, $route, gettextCatalog, gettext, $alert, tmhDynamicLocale) {
    var vm = this;

    vm.isNeedLogin = false;
    vm.login = "";
    vm.password = "";

    vm.initPage = "/viewLogin";
    vm.processLogin = false;

    vm.locale_front2back = [];
    vm.locale_front2back['ru'] = 'rus';
    vm.locale_front2back['en'] = 'eng';
    vm.locale_front2back['zh'] = 'zho';

    vm.locale_front2i18m = [];
    vm.locale_front2i18m['ru'] = 'ru-ru';
    vm.locale_front2i18m['en'] = 'en-us';
    vm.locale_front2i18m['zh'] = 'zh-cn';

    vm.setLocale = function(locale) {
        gettextCatalog.setCurrentLanguage(locale);
        localStorage.setItem('curLocale', locale);
        tmhDynamicLocale.set(vm.locale_front2i18m[locale]);
    };

    vm.options = {
        locale: 'ru'
    };

    if(localStorage.getItem('curLocale') != null) {
      vm.options.locale = localStorage.getItem('curLocale');
    }

    vm.setLocale(vm.options.locale);

    vm.doLogin = function (account) {
        if(vm.processLogin) return;
        var params = account || {
                login: vm.login,
                password: vm.password,
                lang: vm.locale_front2back[vm.options.locale]
            };
        vm.processLogin = true;
        $http.post('/api/auth/login', params)
            .then(function successCallback(response) { // response status code between 200 and 299
                vm.processLogin = false;
                var result = response.data;
                var status = response.status;
                console.log("'/api/tokenauth/authorize', response.status: " + response.status);
                sessionStorage.setItem('login', vm.login);
                vm.initPage = result.initPage;
                vm.getRoles();
            }, function errorCallback(response) {
                vm.processLogin = false;
                console.log("/api/tokenauth/authorize, error.status: " + response.status);
                $alert({
                    title: gettextCatalog.getString('Ошибка авторизации'),
                    content: response.data.alerts[0].msg,
                    templateUrl: "errorAlert.html",
                    duration: 2,
                    placement: 'top-right',
                    type: response.data.alerts[0].type,
                    show: true
                });
            });
    };

    vm.getRoles = function () {
        var params = {
            lang: vm.locale_front2back[vm.options.locale]
        };

        $http.post('/api/auth/roles', params)
            .then(function successCallback(response) {  // response status code between 200 and 299
                var result = response.data;
                var status = response.status;
                console.log("'/api/auth/roles', response.status: " + response.status);
                sessionStorage.setItem('roles', JSON.stringify(result["roles"]));
                var urlToRestoreAfterAuth = sessionStorage.getItem('urlToRestoreAfterAuth');
                if(urlToRestoreAfterAuth) {
                    sessionStorage.removeItem('urlToRestoreAfterAuth');
                    $location.path(urlToRestoreAfterAuth);
                } else {
                    $location.path(vm.initPage);
                }
            }, function errorCallback(response) {
                console.log("/api/auth/roles, error.status: " + response.status);
                if(response.data.alerts) {
                    $alert({
                        title: gettextCatalog.getString('Ошибка авторизации'),
                        content: response.data.alerts[0].msg,
                        templateUrl: "errorAlert.html",
                        duration: 2,
                        placement: 'top-right',
                        type: response.data.alerts[0].type,
                        show: true
                    });
                }
            });
    };

    // autologin по токену из localStorage
    vm.autoLogin = function () {
        var params = {};

        $http.post('/api/auth/checkLogin', params)
            .then(function successCallback(response) {  // response status code between 200 and 299
                var result = response.data;
                var status = response.status;
                console.log("'/api/auth/checkLogin', response.status: " + response.status);
                sessionStorage.setItem('login', result.login);
                console.log('restore login:', result.login);
                vm.initPage = result.initPage;
                vm.getRoles();
            }, function errorCallback(response) {
                console.log("/api/auth/checkLogin, error.status: " + response.status);
                console.log('no login for restore');
                vm.isNeedLogin = true;
            });
    };
    vm.autoLogin();

    if(sessionStorage.getItem('login')) {
        vm.login = sessionStorage.getItem('login');
    }
}

angular.module('myApp.viewLogin', ['ngAnimate', 'ngRoute', 'ui.bootstrap'])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/viewLogin', {
            templateUrl: 'viewLogin/viewLogin.html',
            //controller: 'ViewContractController'
        });
    }])
    .controller('ViewLoginController', ViewLoginController);
