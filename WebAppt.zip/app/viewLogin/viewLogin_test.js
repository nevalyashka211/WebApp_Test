'use strict';

describe('pandaApp.viewLogin module', function() {

  beforeEach(module('pandaApp.viewLogin'));

  describe('viewLogin controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var viewLoginCtrl = $controller('ViewLoginCtrl');
      expect(viewLoginCtrl).toBeDefined();
    }));

  });
});