'use strict';

describe('appPanda.viewContract module', function() {

  beforeEach(module('appPanda.viewContract'));

  describe('viewContract controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var viewContractCtrl = $controller('ViewContractCtrl');
      expect(viewContractCtrl).toBeDefined();
    }));

  });
});