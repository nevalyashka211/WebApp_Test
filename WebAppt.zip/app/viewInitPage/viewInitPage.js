'use strict';
function ViewInitPageController($scope, $location, $http, $q, $route, gettextCatalog, gettext) {
    var vm = this;
    var auth = restoreAuth($http, $location, $q);
    
    
    //load and date heatmap
    
    $scope.untilDatep = new Date();
    $scope.fromDatep = new Date($scope.untilDatep - 1000*60*60*24);
    
    
    function loading(par) {
        var arr = [];
        $http.post('/api/heatmap/load', par)
            .then(function successCallback(response){
                // console.log(JSON.stringify(response.data, null, 2));
                arr = response.data;
                points = [];
                arr.forEach(function(p){
                    points.push(p);
                });
                var data = {
                    max: 50,
                    min: 0,
                    data: arr
                };
                console.log(arr);
                heatmapInstance.setData(data);
            });
    }

    auth.then(function successCallback(auth) {
        vm.login = auth.login;

        /*var role = getRole(auth.roles);
        if (role == null) {
            $location.path('/viewNotValidRoles?');
        } else {
            vm.role = role;
        }
*/
        var params = {
            nameP: vm.login,
            untilD: $scope.untilDatep,
            fromD: $scope.fromDatep
        };
        loading(params);
        // load data for form
        vm.loadListValues('contractType', 'CONTRACT_TYPE');
        vm.loadListValues('contractStatus', 'CONTRACT_STATUS');

    }, function errorCallback(authPath) {
        $location.path(authPath);
    });
    vm.locale_front2back = [];
    vm.locale_front2back['ru'] = 'rus';
    vm.locale_front2back['en'] = 'eng';
    vm.locale_front2back['zh'] = 'zho';

    vm.setLocale = function(locale) {
        gettextCatalog.setCurrentLanguage(locale);
    };

    vm.options = {
        locale: 'ru'
    };

    if(localStorage.getItem('curLocale') != null) {
        vm.options.locale = localStorage.getItem('curLocale');
    }

    vm.setLocale(vm.options.locale);

    vm.selects = [];

    vm.loadListValues = function (modelObj, fieldName) {
        var params = {
            apiName: 'contract',
            apiPath: '/api/contract/getFieldValues',
            lang: vm.locale_front2back[vm.options.locale], 
            limit: 10, 
            field: fieldName, 
            value: ''
        };
        return $http.post('/api/preback', params)
            .then(function successCallback(response) { // response status code between 200 and 299
                var data = response.data;
                var status = response.status;
                console.log("/api/contract/getFieldValues, response.status: " + response.status);
                var items = [];
                var item;
                for (var i = 0; i < data.items.length; i++) {
                    item = data.items[i];
                    items.push({code: item.code, name: item.name});
                }
                vm.selects[modelObj] = items;
            }, function errorCallback(response) {
                console.log("/api/contract/getFieldValues, error.status: " + response.status);
                if (response.status == 401) {
                    sessionStorage.removeItem('roles');
                    $location.path('/viewLogin');
                } else {
                    return [];
                }
            });
    };

    vm.doLogout = function() {
        var params = {
            lang: vm.locale_front2back[vm.options.locale]
        };
        sessionStorage.removeItem('roles');
        $http.post('/api/auth/logout', params)
            .then(function successCallback(response) { // response status code between 200 and 299
                var result = response.data;
                var status = response.status;
                console.log("'/api/auth/logout', response.status: " + response.status);
                $location.path('/viewLogin?');
            }, function errorCallback(response) {
                console.log("/api/auth/logout, error.status: " + response.status);
                $location.path('/viewLogin?');
            });
    };

    vm.doHelp = function() {
        var params = {
            lang: vm.locale_front2back[vm.options.locale],
            section: "contract",
            page: "viewInitPage"
        };

        var winName = "help_" + params.section + "_" + params.page + "_" + params.lang;

        var pars = [];
        var key;
        for (key in params) {
            pars.push(key + '=' + encodeURIComponent(params[key]));
        }

        window.open("/api/help" + '?' + pars.join('&'), winName);
    };
    

    vm.doLoadAllHeatmap = function (fromDatep,untilDatep) {
        var params = {
            nameP: "all",
            fromD: fromDatep,
            untilD: untilDatep
        };
        loading(params);
    };

}

var myApp = angular.module('myApp.viewInitPage', ['ngRoute'])
    .config(['$routeProvider', function ($routeProvider) {
        $routeProvider.when('/viewInitPage', {
            templateUrl: 'viewInitPage/viewInitPage.html'
            //controller: 'ViewInitPageController'
        });
    }]).config(function($datepickerProvider) {
        angular.extend($datepickerProvider.defaults, {
            dateFormat: 'dd/MM/yyyy',
            startWeek: 1
        });
    })
    .controller('ViewInitPageController', ViewInitPageController);


//---------------------------------------------------------
//HEATMAP
//---------------------------------------------------------
var points = [];
var heatmapInstance;

myApp.controller('PointsController', function ($scope, $document) {
});


myApp.directive('heatMap', function(){
        return {
            restrict: 'E',
            scope: {
                data: '='
            },
            template: '<div container></div>',
            link: function (scope, ele) {
                heatmapInstance = h337.create({
                    container: ele.find('div')[0],
                    radius: 50,
                    maxOpacity: .8,
                    minOpacity: 0
                });

            },
            controller: function ($scope, $document, $http) {
              //  localStorage.removeItem('points');
                var pointsTimeOut = [];
                var i = 0;
                /*var params = {
                    nameP: paramName
                };
                $http.post('/api/heatmap/load',params)
                    .then(function successCallback(response){
                    // console.log(JSON.stringify(response.data, null, 2));
                    var arr = response.data;
                    arr.forEach(function(p){
                        points.push(p);
                    });
                    var data = {
                        max: 50,
                        min: 0,
                        data: points
                    };
                    heatmapInstance.setData(data);
                });*/
                /* if( localStorage.getItem('points')!= null) {
                     console.log(localStorage.getItem('points'));
                     var pt = JSON.parse(localStorage.getItem('points'));
                     points = pt.slice(1);
                     }*/
                $document.find('body').on("click", function (ev) {
                    var point = {
                        x: ev.pageX,
                        y: ev.pageY,
                        value: 1
                    };
                    points.push(point);
                    pointsTimeOut.push(point);
                    
                    i++;
                    var data = {
                        max: 50,
                        min: 0,
                        data: points
                    };
                    heatmapInstance.setData(data);
                });
                setInterval(function () {
                       // var params ={pointsTO:pointsTimeOut, nameP:userName};
                    if(pointsTimeOut != 0) {
                        $http.post('/api/heatmap/save', pointsTimeOut).then(function successCallback() {
                            console.log(pointsTimeOut);
                            pointsTimeOut = [];
                        }, function errorCallback() {
                            console.log("error :(");
                        });
                    } else if(pointsTimeOut != null){
                            //console.log("Data = null");
                    }
                        // localStorage.setItem("points", JSON.stringify(points));
                        // console.log(localStorage["points"]);
                }, 5000);
            },
            controllerAs:'pointsCtrl'
        };
    });