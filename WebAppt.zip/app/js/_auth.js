function getRole(roles) {
    var isSuperuser = false;
    var isAuditor = false;
    var isManager = false;

    for(var i = 0; i < roles.length; i++) {
        var role_name = roles[i].name;
        if(role_name == 'Менеджер продаж') isManager = true;
        if(role_name == 'Аудитор договоров') isAuditor = true;
        if(role_name == 'Суперпользователь договоров') isSuperuser = true;
    }
    var role = null;

    if(isManager) role = "manager";
    if(isAuditor) role = "auditor";
    if(isSuperuser) role = "superuser";

    return role;
}

function getRoles($http, $q) {
    var params = {};

    var deferred = $q.defer();

    $http.post('/api/auth/roles', params)
        .then(function successCallback(response) {  // response status code between 200 and 299
            var result = response.data;
            var status = response.status;
            console.log("'/api/auth/roles', response.status: " + response.status);
            sessionStorage.setItem('roles', JSON.stringify(result["roles"]));
            deferred.resolve(result["roles"]);
        }, function errorCallback(response) {
            deferred.reject('/viewLogin?');
        });
    return deferred.promise;
}

function getLoginFromSession($http, $q) {
    var params = {};

    var deferred = $q.defer();

    $http.post('/api/auth/checkLogin', params)
        .then(function successCallback(response) {  // response status code between 200 and 299
            var result = response.data;
            var status = response.status;
            console.log("'/api/auth/checkLogin', response.status: " + response.status);
            sessionStorage.setItem('login', result.login);
            console.log('restore login from session:', result.login);
            deferred.resolve(result["login"]);
        }, function errorCallback(response) {
            console.log("/api/auth/checkLogin, error.status: " + response.status);
            console.log('no login for restore');
            deferred.reject('/viewLogin?');
        });
    return deferred.promise;
}

function restoreAuth($http, $location, $q) {

    var deferred = $q.defer();
    var promiseLogin = getLoginFromSession($http, $q);
    promiseLogin.then(function successCallback(login) {
        var promiseRoles = getRoles($http, $q);
        promiseRoles.then(function successCallback(roles) {
            if (roles == null) {
                deferred.reject('/viewNotAnyRoles?');
            } else {
                deferred.resolve(
                    {
                        login: login,
                        roles: roles
                    }
                );
            }
        }, function errorCallback(errRedirectPath) {
            deferred.reject(errRedirectPath);
        });

    }, function errorCallback(errRedirectPath) {
        deferred.reject(errRedirectPath);
    });
    return deferred.promise;
}
