module.exports = function(grunt) {

grunt.initConfig({
  nggettext_extract: {
    pot: {
      files: {
        'po/template.pot': ['app/viewLogin/*.html', 'app/viewLogin/*.js',
		'app/viewContract/*.html', 'app/viewContract/*.js', 
		'app/viewContractEdit/*.html', 'app/viewContractEdit/*.js', 
		'app/viewBadRoles/*.html', 'app/viewBadRoles/*.js', 
		'app/modal/*.html',
		'app/index.html',
		'app/components/contract/steps/*.html']
      }
    },
  },
  nggettext_compile: {
    all: {
      options: {
        //module: 'appPanda'
      },
      files: {
        'app/js/translations.js': ['po/*.po']
      }
    },
  }
});

grunt.loadNpmTasks('grunt-angular-gettext');

grunt.registerTask('extract', ['nggettext_extract']);

grunt.registerTask('compile', ['nggettext_compile']);


}